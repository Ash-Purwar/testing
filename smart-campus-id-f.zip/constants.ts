
export const CAMPUS_LOCATION = {
  lat: 40.785091,
  lng: -73.968285,
  radius: 100 // meters
};

export const APP_NAME = "Smart Campus Identity";
